<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tableModel extends Model
{
    //
}
